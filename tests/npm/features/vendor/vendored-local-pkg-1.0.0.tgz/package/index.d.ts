export declare const vendored: string;
