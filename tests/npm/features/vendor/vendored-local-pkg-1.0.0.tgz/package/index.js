exports.vendored = "from a local tarball";
